import numpy as np
import random
import sys
import matplotlib.pyplot as plt
from tqdm import tqdm

def calc_extremums(id, matrix, type):

    if type == 'L1':
        d = np.sum(abs(matrix[id]-matrix), axis = 1)
    elif type == 'L2':
        d = np.sum((matrix[id]-matrix)**2, axis = 1)
    else:
        d = np.max(abs(matrix[id]-matrix), axis = 1)

    farthest = np.max(d)
    f_id = np.argmax(d)
    d[id] = float('inf')
    c_id = np.argmin(d)
    closest = np.min(d)

    return farthest, f_id, closest, c_id


N = int(sys.argv[1])

dist_types = ['L1', 'L2', 'L_Inf']
colors = ['r', 'g', 'b']

dimensions = [1,2,4,8,16,32,64]
avg_ratio = [[0]*7 for i in range(3)]

for d_id in range(len(dimensions)):

    print("Number of dimensions:", dimensions[d_id])
    ilist = random.sample(range(int(1e6)), 100)
    d = dimensions[d_id]
    matrix = np.zeros((N,d))
    for i in range(d):
        matrix[:,i] = np.random.random_sample((N,))

    for type_id in range(len(dist_types)):

        print("Executing for {}".format(dist_types[type_id]))

        for i in tqdm(ilist):
            farthest, f_id, closest, c_id = calc_extremums(i, matrix, dist_types[type_id])
            avg_ratio[type_id][d_id] += farthest/closest
            # print(f_id, farthest, c_id, closest)
            # print(matrix[i], matrix[f_id], matrix[c_id])
            # print()

        # print()
        avg_ratio[type_id][d_id] /= len(ilist)
        # print(avg_ratio)
        # print()
        # print()
    print()

plt.xlabel('dimension')
plt.ylabel('log(avg_ratio)')
plt.title('Plots for L1, L2 and L_inf')

for i in range(3):
    plt.plot(dimensions, np.log(np.array(avg_ratio[i])), colors[i])

plt.legend(['L1', 'L2', 'L_inf'])

plt.show()
