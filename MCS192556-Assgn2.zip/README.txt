
Assignment 2:
======================================================================================================

#Q1:
------------------------------------------------------------------------------------------------------

##CREATE PLOTS:
To plot the graphs, execute "sh MCS192556.sh" in the terminal.

##STEPS TAKEN IN THE CODE:
1.) For each dimension value d in {2,4,8,16,32,64}, generate 1000000 data points with d dimensions.
2.) Select 100 query points at random from the dataset
3.) For each of L1, L2 and L_inf distances, calculate the average ratio of distances to farthest and closest
    points to these query points (while a query point is being considered, it has been removed from the dataset)
    for each value of d.
4.) Plot the natural log of average ratio to the number of dimensions. Plot will be saved in file plot.png


#Team Members
------------------------------------------------------------------------------------------------------
2019MCS2554. Aaditya Sinha
2019MCS2556. Akshay Gupta
2019MCS2574. Vivek Singh
