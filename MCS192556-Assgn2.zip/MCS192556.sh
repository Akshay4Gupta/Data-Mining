python3 Q1.py 1000000
