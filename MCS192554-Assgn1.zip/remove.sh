rm fptree
rm apriori
rm *.txt
